import { Component, OnInit } from '@angular/core';
import { User } from '../app.component';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user: User;
  name: string;
  lname: string;
  role: string = 'student';
  phone: string;
  email: string;
  company: string;
  department: string;

  constructor(
    private userService: UserService,
  ) { }

  ngOnInit(): void {
  }

  callUser(): void{
    this.user = {
      name: this.name,
      lname: this.lname,
      role: this.role,
      phone: this.phone,
      email: this.email,
      company: this.company,
      department: this.department,
    }
    console.log(this.user);
    this.userService.newUser(this.user, (error, result) => {
      console.log(result);
      console.log(error);
    })
  }

}
