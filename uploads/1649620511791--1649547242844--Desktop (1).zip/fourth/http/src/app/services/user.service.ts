import { Injectable } from '@angular/core';
import { User } from '../app.component';
import { ServerAPIService } from './server-api.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users: User[];

  constructor(
    private api: ServerAPIService,
  ) { }

  newUser(data, callback){
    let dataServer = {
      user: data
    }
    this.api.newUser(JSON.stringify(dataServer))
    .subscribe((res:any)=>{
      callback(null, res);
    }, (error) => {
      console.log('error',error);
      callback(error, null);
    });
  }

  allUsers(callback){
    this.api.users()
    .subscribe((res:any)=>{
      this.users= res;
      callback(null, res);
    }, (error) => {
      console.log('error',error);
      callback(error, null);
    });
  }
}
