import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class ServerAPIService {
  constructor(private http: HttpClient) {}

  newUser(data: string) {
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
    };
    return this.http.post(
      'http://localhost:3111/users/newuser',
      data,
      httpOptions
    );
  }

  users() {
    return this.http.get('http://localhost:3111/users/users');
  }
}
