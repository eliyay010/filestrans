import { Component, OnInit } from '@angular/core';
import { User } from '../app.component';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-usres',
  templateUrl: './usres.component.html',
  styleUrls: ['./usres.component.css']
})
export class UsresComponent implements OnInit {
  users: User[]= [];

  constructor(
    private userservice: UserService,
  ) { }

  ngOnInit(): void {
    this.userservice.allUsers((error, data) => {
      console.log(data);
      this.users = this.userservice.users;
    })
  }

}
