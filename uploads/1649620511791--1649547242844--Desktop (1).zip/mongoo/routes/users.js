const express = require('express');
const router = express.Router();
const { usersController } = require('../controlles/usersController');
/* GET users listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

router.get('/users', (req, res) => usersController.users(req, res));
router.post('/newuser', (req, res) => usersController.newUser(req, res));
router.post('/updateuser', (req, res) => usersController.updateUser(req, res));

module.exports = router;