const { userService } = require('../services/userService');
class UsersController {

    constructor() {}

    users(req, res) {
        console.log('controller');
        userService.users((err, data) => {
            console.log('controller service');
            if (err) res.status(400).json({ reason: 'Error in Data Base' })
            else res.json(data);
        });
    }
    newUser(req, res) {
        userService.newUser(req.body.user, (err, data) => {
            if (err) res.status(400).json({ reason: 'Error in Data Base' })
            else res.json(data);
        });
    }
    updateUser(req, res) {
        userService.updateUser(req.body.user, (err, data) => {
            if (err) res.status(400).json({ reason: 'Error in Data Base' })
            else res.json(data);
        });
    }

}

module.exports = {
    usersController: new UsersController()
}